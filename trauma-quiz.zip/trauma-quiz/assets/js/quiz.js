(function($) {
    'use strict';

    let answers = [];
    let totalQuestions = 0;

    function init() {
        if (typeof traumaQuiz === 'undefined' || !traumaQuiz.perguntas) {
            console.error('TraumaQuiz: dados não carregados.');
            return;
        }
        totalQuestions = traumaQuiz.perguntas.length;

        $('#quiz-start-btn').on('click', startQuiz);
        $('#quiz-restart-btn').on('click', restartQuiz);
        $('#quiz-data-form').on('submit', submitData);
    }

    function startQuiz() {
        $('#quiz-screen-welcome').hide();
        $('#quiz-screen-questions').show();
        $('#quiz-progress').show();
        renderQuestion(0);
    }

    function renderQuestion(index) {
        const pergunta = traumaQuiz.perguntas[index];
        const html = `
            <div class="quiz-question">
                <h3>${pergunta.texto}</h3>
                <div class="quiz-options">
                    ${pergunta.opcoes.map((op, i) => `
                        <label>
                            <input type="radio" name="q${pergunta.id}" value="${op.valor}" data-index="${i}">
                            ${op.label}
                        </label>
                    `).join('')}
                </div>
            </div>
            <div class="quiz-nav">
                <button type="button" class="quiz-btn outline" id="quiz-prev-btn" ${index === 0 ? 'disabled' : ''}>Anterior</button>
                <button type="button" class="quiz-btn primary" id="quiz-next-btn">${index === totalQuestions - 1 ? 'Ver resultado' : 'Próxima'}</button>
            </div>
        `;
        $('#quiz-screen-questions').html(html);
        updateProgress(index);

        if (answers[index] !== undefined && answers[index] !== null) {
            $(`input[name="q${pergunta.id}"][value="${answers[index]}"]`).prop('checked', true);
        }

        $('#quiz-prev-btn').on('click', function() {
            saveAnswer(index);
            if (index > 0) renderQuestion(index - 1);
        });

        $('#quiz-next-btn').on('click', function() {
            const selected = $(`input[name="q${pergunta.id}"]:checked`).val();
            if (selected === undefined) {
                alert('Por favor, selecione uma opção.');
                return;
            }
            saveAnswer(index);
            if (index === totalQuestions - 1) {
                showDataScreen();
            } else {
                renderQuestion(index + 1);
            }
        });
    }

    function saveAnswer(index) {
        const pergunta = traumaQuiz.perguntas[index];
        const val = $(`input[name="q${pergunta.id}"]:checked`).val();
        if (val !== undefined) {
            answers[index] = parseInt(val, 10);
        }
    }

    function updateProgress(index) {
        const pct = ((index + 1) / totalQuestions) * 100;
        $('.progress-fill').css('width', pct + '%');
        $('.progress-text').text(`Questão ${index + 1} de ${totalQuestions}`);
    }

    function showDataScreen() {
        $('#quiz-screen-questions').hide();
        $('#quiz-screen-data').show();
        $('#quiz-progress').hide();
    }

    function submitData(e) {
        e.preventDefault();
        const form = $('#quiz-data-form');
        const errorEl = $('#quiz-data-error');
        errorEl.text('');

        const data = {
            action: 'submit_trauma_quiz',
            nonce: traumaQuiz.nonce,
            respostas: answers,
            nome:         form.find('[name="nome"]').val().trim(),
            email:        form.find('[name="email"]').val().trim(),
            telefone:     form.find('[name="telefone"]').val().trim(),
            idade:        form.find('[name="idade"]').val(),
            genero:       form.find('[name="genero"]').val(),
            consentimento: form.find('[name="consentimento"]').is(':checked') ? 1 : 0,
        };

        if (!data.nome || !data.email || !data.consentimento) {
            errorEl.text('Preencha todos os campos obrigatórios (*).');
            return;
        }

        const submitBtn = form.find('button[type="submit"]');
        submitBtn.prop('disabled', true).text('Enviando...');

        $.post(traumaQuiz.ajax_url, data)
            .done(function(response) {
                // Proteção contra retorno "-1" (nonce do WordPress)
                if (typeof response === 'string') {
                    errorEl.text('Erro de segurança. Recarregue a página e tente novamente.');
                    return;
                }
                if (response && response.success) {
                    showResult(response.data);
                } else {
                    const msg = (response && response.data && response.data.message) || 'Erro ao enviar.';
                    errorEl.text(msg);
                }
            })
            .fail(function(xhr) {
                console.error('TraumaQuiz AJAX error:', xhr.status, xhr.responseText);
                let msg = 'Erro de conexão. Tente novamente.';
                if (xhr.status === 403) {
                    msg = 'Sessão expirada. Recarregue a página e tente novamente.';
                } else if (xhr.status === 400) {
                    msg = 'Dados inválidos. Verifique suas respostas.';
                } else if (xhr.responseText && xhr.responseText.length < 200) {
                    msg = 'Erro: ' + xhr.responseText;
                }
                errorEl.text(msg);
            })
            .always(function() {
                submitBtn.prop('disabled', false).text('Enviar respostas');
            });
    }

    function showResult(data) {
        $('#quiz-screen-data').hide();
        $('#quiz-screen-result').show();

        const nivelClass = 'nivel-' + (data.nivel || '').toLowerCase().replace(/\s+/g, '-');
        const html = `
            <h3 class="${nivelClass}">${data.nivel}</h3>
            <p>${data.mensagem}</p>
            <p class="pontuacao">Pontuação total: ${data.pontuacao} de ${totalQuestions * 4}</p>
        `;
        $('#quiz-result-content').html(html);
    }

    function restartQuiz() {
        answers = [];
        $('#quiz-screen-result').hide();
        $('#quiz-screen-welcome').show();
        $('#quiz-screen-data').hide();
        $('#quiz-screen-questions').hide();
        $('#quiz-progress').hide();
        $('#quiz-data-form')[0].reset();
        $('#quiz-data-error').text('');
    }

    $(document).ready(init);

})(jQuery);