<?php
/**
 * Plugin Name:       Trauma Quiz
 * Plugin URI:        https://psilidia.com/#teste_traumas
 * Description:       A light questionnaire for assessing trauma symptoms, LGPD-compliant, with personalized feedback and CSV data export.
 * Version:           1.3
 * Author:            Alberto Lima Digital
 * Author URI:        https://albertolimadigital.com
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       trauma-quiz
 * Domain Path:       /languages
 *
 * @package TraumaQuiz
 */

if (!defined('ABSPATH')) exit;

class TraumaQuiz {

    const VERSION    = '1.0.2';
    const DB_VERSION = '1.0.2';

    private static $instance = null;
    private $table_name;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'trauma_quiz_responses';

        add_action('init',               [$this, 'init']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_menu',         [$this, 'admin_menu']);
        add_action('admin_init',         [$this, 'maybe_upgrade']);

        add_action('admin_post_trauma_quiz_export', [$this, 'handle_export']);
        add_action('admin_post_trauma_quiz_clear',  [$this, 'handle_clear']);

        add_action('wp_ajax_submit_trauma_quiz',        [$this, 'ajax_submit']);
        add_action('wp_ajax_nopriv_submit_trauma_quiz', [$this, 'ajax_submit']);

        add_filter('wp_privacy_personal_data_exporters', [$this, 'register_exporter']);
        add_filter('wp_privacy_personal_data_erasers',   [$this, 'register_eraser']);

        register_activation_hook(__FILE__, [$this, 'activate']);
    }

    /* ============================================================
     *  BANCO DE DADOS
     * ============================================================ */

    public function activate() {
        $this->create_table();
        update_option('trauma_quiz_db_version', self::DB_VERSION);
    }

    public function maybe_upgrade() {
        if (get_option('trauma_quiz_db_version') !== self::DB_VERSION) {
            $this->create_table();
            update_option('trauma_quiz_db_version', self::DB_VERSION);
        }
    }

    private function create_table() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = esc_sql($this->table_name); // 👇 CORRIGIDO AQUI (Missão 4)
        $sql = "CREATE TABLE {$table_name} (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            telefone VARCHAR(20),
            idade INT,
            genero VARCHAR(20),
            respostas TEXT NOT NULL,
            pontuacao INT NOT NULL,
            nivel VARCHAR(50) NOT NULL,
            consentimento TINYINT(1) DEFAULT 0,
            data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip VARCHAR(45)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /* ============================================================
     *  INICIALIZAÇÃO E ASSETS
     * ============================================================ */

    public function init() {
        add_shortcode('trauma_quiz', [$this, 'render_quiz']);
    }

    public function enqueue_assets() {
        $path = plugin_dir_path(__FILE__);
        $url  = plugin_dir_url(__FILE__);

        $css_url = file_exists($path . 'assets/css/quiz.css') ? $url . 'assets/css/quiz.css' : $url . 'quiz.css';
        $js_url  = file_exists($path . 'assets/js/quiz.js')   ? $url . 'assets/js/quiz.js'   : $url . 'quiz.js';

        wp_enqueue_style('trauma-quiz-style', $css_url, [], self::VERSION);
        wp_enqueue_script('trauma-quiz-script', $js_url, ['jquery'], self::VERSION, true);

        wp_localize_script('trauma-quiz-script', 'traumaQuiz', [
            'ajax_url'  => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('trauma_quiz_nonce'),
            'perguntas' => $this->get_questions(),
            'faixas'    => $this->get_score_ranges(),
        ]);
    }

    /* ============================================================
     *  PERGUNTAS E FAIXAS
     * ============================================================ */

    private function get_questions() {
        return [
            ['id'=>1,'texto'=>'Você tem dificuldade para dormir porque sua mente fica ocupada com pensamentos ou lembranças que parecem difíceis de controlar?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>2,'texto'=>'Lembranças de situações difíceis que você viveu surgem de repente em sua mente, mesmo quando você preferiria não pensar nelas?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>3,'texto'=>'Você costuma evitar determinados lugares, pessoas, conversas ou situações porque eles despertam lembranças de algo doloroso que aconteceu?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>4,'texto'=>'No dia a dia, você se sente facilmente irritado(a), assustado(a), nervoso(a) ou constantemente "no limite"?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>5,'texto'=>'Você sente que precisa estar sempre alerta, como se algo ruim pudesse acontecer a qualquer momento?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>6,'texto'=>'Por causa de experiências que viveu, você costuma sentir culpa, vergonha ou a sensação de ser diferente das outras pessoas?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>7,'texto'=>'Você encontra dificuldade para confiar nas pessoas ou para criar vínculos de proximidade e intimidade emocional?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>8,'texto'=>'Esses sentimentos, pensamentos ou lembranças têm interferido no seu trabalho, nos estudos ou nos seus relacionamentos?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>9,'texto'=>'Você costuma ter pesadelos ou sonhos perturbadores relacionados a acontecimentos do passado?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>10,'texto'=>'Quando alguma coisa desperta uma lembrança do passado, você sente reações físicas intensas, como coração acelerado, suor, falta de ar ou tensão?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>11,'texto'=>'Você sente, às vezes, como se estivesse emocionalmente anestesiado(a), tendo dificuldade para sentir alegria, entusiasmo ou outras emoções positivas?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>12,'texto'=>'Você percebe que tem dificuldade para lembrar de partes importantes de situações difíceis que viveu?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>13,'texto'=>'Você costuma se culpar excessivamente por acontecimentos do passado, mesmo por situações que talvez não estivessem totalmente sob seu controle?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>14,'texto'=>'Você sente que as pessoas ao seu redor não conseguem compreender verdadeiramente aquilo que você passou?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>15,'texto'=>'Você costuma pensar que o mundo é um lugar perigoso ou que não é possível confiar nas pessoas?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>16,'texto'=>'Você se sente constantemente tenso(a), inquieto(a) ou percebe que mantém os músculos contraídos mesmo quando não existe um motivo aparente?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>17,'texto'=>'Você tem dificuldade para se concentrar, até mesmo em tarefas simples do seu cotidiano?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>18,'texto'=>'Você se sente facilmente sobrecarregado(a) por barulhos, ambientes movimentados ou outros estímulos intensos?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>19,'texto'=>'Você evita falar sobre determinadas coisas que aconteceram com você, mesmo quando está diante de pessoas próximas e de confiança?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>20,'texto'=>'Você sente, de alguma forma, que uma parte de você ainda está presa a acontecimentos ou sentimentos do passado?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>21,'texto'=>'Você percebe em si comportamentos impulsivos ou atitudes que acabam sendo prejudiciais para você?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>22,'texto'=>'Às vezes, você sente como se estivesse desconectado(a) do próprio corpo ou tivesse dificuldade para compreender e sentir suas próprias emoções?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>23,'texto'=>'Você já teve pensamentos ou sentimentos de que não merece ser feliz ou de que não merece viver coisas boas?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>24,'texto'=>'Você sente que aquilo que viveu no passado afetou profundamente a maneira como você se enxerga e a sua autoestima?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>25,'texto'=>'Você encontra dificuldade para estabelecer limites nos seus relacionamentos, mesmo quando determinadas situações fazem você se sentir desconfortável?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>26,'texto'=>'Você costuma se sentir isolado(a) ou sozinho(a), mesmo quando está cercado(a) por outras pessoas?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>27,'texto'=>'Você apresenta sintomas físicos, como dores de cabeça, problemas digestivos ou outros desconfortos, sem que uma causa médica clara tenha sido identificada?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>28,'texto'=>'Você sente que talvez nunca consiga superar completamente aquilo que aconteceu no passado?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>29,'texto'=>'Você percebe que perdeu o prazer ou o interesse por atividades que antes gostava de fazer?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
            ['id'=>30,'texto'=>'Você já pensou em procurar ajuda profissional para compreender melhor e lidar com esses pensamentos, sentimentos ou experiências?','opcoes'=>[
                ['label'=>'Nunca','valor'=>0],['label'=>'Raramente','valor'=>1],['label'=>'Às vezes','valor'=>2],['label'=>'Frequentemente','valor'=>3],['label'=>'Sempre','valor'=>4]]],
        ];
    }

    private function get_score_ranges() {
        return [
            ['min'=>0,   'max'=>30,  'nivel'=>'Baixo',      'mensagem'=>'Seus sintomas são leves. Continue cuidando de si!'],
            ['min'=>31,  'max'=>60,  'nivel'=>'Moderado',   'mensagem'=>'Você apresenta alguns sinais de estresse pós-traumático. Considere buscar apoio profissional.'],
            ['min'=>61,  'max'=>90,  'nivel'=>'Alto',       'mensagem'=>'Seus sintomas são significativos. Recomendamos fortemente uma avaliação com um psicólogo especializado em trauma.'],
            ['min'=>91,  'max'=>120, 'nivel'=>'Muito Alto', 'mensagem'=>'Seus sintomas são severos. Procure ajuda imediata. Ligue para o CVV (188) ou busque um serviço de emergência.'],
        ];
    }

    /* ============================================================
     *  FRONTEND (SHORTCODE)
     * ============================================================ */

    public function render_quiz() {
        ob_start(); ?>
        <div id="trauma-quiz-container">
            <div id="quiz-progress" style="display:none;">
                <div class="progress-bar"><span class="progress-fill" style="width:0%;"></span></div>
                <span class="progress-text">Questão 1 de <?php echo count($this->get_questions()); ?></span>
            </div>
            <div id="quiz-screen-welcome" class="quiz-screen">
                <h2>Questionário de Rastreio de Trauma</h2>
                <p>Este questionário ajuda a identificar sintomas relacionados a experiências traumáticas. Suas respostas são confidenciais e serão usadas apenas para fins de orientação.</p>
                <button id="quiz-start-btn" class="quiz-btn primary" type="button">Iniciar</button>
            </div>
            <div id="quiz-screen-questions" class="quiz-screen" style="display:none;"></div>
            <div id="quiz-screen-data" class="quiz-screen" style="display:none;">
                <h3>Para finalizar, preencha seus dados:</h3>
                <form id="quiz-data-form" novalidate>
                    <p><label>Nome* <input type="text" name="nome" required></label></p>
                    <p><label>E-mail* <input type="email" name="email" required></label></p>
                    <p><label>Telefone <input type="tel" name="telefone"></label></p>
                    <p><label>Idade <input type="number" name="idade" min="10"></label></p>
                    <p><label>Gênero
                        <select name="genero">
                            <option value="">Prefiro não dizer</option>
                            <option>Feminino</option><option>Masculino</option><option>Outro</option>
                        </select></label></p>
                    <p><label><input type="checkbox" name="consentimento" required> Concordo com o tratamento dos meus dados conforme a <a href="/politica-privacidade" target="_blank">Política de Privacidade</a> *</label></p>
                    <button type="submit" class="quiz-btn primary">Enviar respostas</button>
                </form>
                <div id="quiz-data-error" class="error-message"></div>
            </div>
            <div id="quiz-screen-result" class="quiz-screen" style="display:none;">
                <h2>Seu resultado</h2>
                <div id="quiz-result-content"></div>
                <p><a href="/agendamento" class="quiz-btn secondary">Agendar consulta</a></p>
                <button id="quiz-restart-btn" class="quiz-btn outline" type="button">Refazer teste</button>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
     *  AJAX — ENVIO DO FORMULÁRIO
     * ============================================================ */

    public function ajax_submit() {
        if (!check_ajax_referer('trauma_quiz_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Sessão expirada. Recarregue a página e tente novamente.']);
        }

        $respostas = [];
        if (isset($_POST['respostas']) && is_array($_POST['respostas'])) {
            $respostas = array_values(array_map('intval', wp_unslash($_POST['respostas'])));
        }

        $nome          = isset($_POST['nome'])         ? sanitize_text_field(wp_unslash($_POST['nome']))     : '';
        $email         = isset($_POST['email'])        ? sanitize_email(wp_unslash($_POST['email']))          : '';
        $telefone      = isset($_POST['telefone'])     ? sanitize_text_field(wp_unslash($_POST['telefone'])) : '';
        $idade         = isset($_POST['idade'])        ? intval($_POST['idade'])                                : 0;
        $genero        = isset($_POST['genero'])       ? sanitize_text_field(wp_unslash($_POST['genero']))   : '';
        $consentimento = (!empty($_POST['consentimento'])) ? 1 : 0;
        
        // 👇 CORRIGIDO AQUI (Missão 3)
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

        if (empty($respostas)) {
            wp_send_json_error(['message' => 'Nenhuma resposta recebida.']);
        }
        if (count($respostas) < count($this->get_questions())) {
            wp_send_json_error(['message' => 'Responda todas as perguntas antes de enviar.']);
        }
        if (empty($nome) || empty($email)) {
            wp_send_json_error(['message' => 'Nome e e-mail são obrigatórios.']);
        }
        if (!is_email($email)) {
            wp_send_json_error(['message' => 'E-mail inválido.']);
        }
        if (!$consentimento) {
            wp_send_json_error(['message' => 'É necessário consentir com o tratamento de dados.']);
        }

        $total    = array_sum($respostas);
        $nivel    = '';
        $mensagem = '';
        foreach ($this->get_score_ranges() as $f) {
            if ($total >= $f['min'] && $total <= $f['max']) {
                $nivel    = $f['nivel'];
                $mensagem = $f['mensagem'];
                break;
            }
        }
        if ($nivel === '') {
            $faixas   = $this->get_score_ranges();
            $ultima   = end($faixas);
            $nivel    = $ultima['nivel'];
            $mensagem = $ultima['mensagem'];
        }

        global $wpdb;
        // 👇 CORRIGIDO AQUI (Missão 4)
        $table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $this->table_name ) );
        if ( $table_exists !== $this->table_name ) {
            $this->create_table();
        }

        $inserted = $wpdb->insert(
            $this->table_name,
            [
                'nome'          => $nome,
                'email'         => $email,
                'telefone'      => $telefone,
                'idade'         => $idade,
                'genero'        => $genero,
                'respostas'     => maybe_serialize($respostas),
                'pontuacao'     => $total,
                'nivel'         => $nivel,
                'consentimento' => $consentimento,
                'ip'            => $ip,
            ],
            ['%s','%s','%s','%d','%s','%s','%d','%s','%d','%s']
        );

        if ($inserted === false) {
            // 👇 CORRIGIDO AQUI (Missão 5: Removido o error_log)
            wp_send_json_error(['message' => 'Erro ao salvar no banco de dados.']);
        }

        wp_send_json_success([
            'nivel'     => $nivel,
            'mensagem'  => $mensagem,
            'pontuacao' => $total,
        ]);
    }

    /* ============================================================
     *  ADMIN
     * ============================================================ */

    public function admin_menu() {
        add_menu_page('Trauma Quiz Respostas', 'Trauma Quiz', 'manage_options', 'trauma-quiz', [$this, 'admin_page'], 'dashicons-clipboard', 30);
    }

    public function admin_page() {
        global $wpdb;
        // 👇 CORRIGIDO AQUI (Missão 4: esc_sql no nome da tabela)
        $table_name = esc_sql($this->table_name);
        $results = $wpdb->get_results( 
    $wpdb->prepare( "SELECT * FROM %i ORDER BY data_hora DESC", $table_name ) 
); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        
        $export_url = wp_nonce_url(admin_url('admin-post.php?action=trauma_quiz_export'), 'trauma_quiz_export');
        $clear_url  = wp_nonce_url(admin_url('admin-post.php?action=trauma_quiz_clear'),  'trauma_quiz_clear');
        ?>
        <div class="wrap">
            <h1>Respostas do Trauma Quiz</h1>

            <?php // 👇 CORRIGIDO AQUI (Missão 3: Sanitização do $_GET) ?>
            <?php if (isset($_GET['cleared']) && '1' === $_GET['cleared']): // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
                <div class="notice notice-success is-dismissible">
                    <p>Todos os resultados foram apagados com sucesso.</p>
                </div>
            <?php endif; ?>

            <p>
                <a href="<?php echo esc_url($export_url); ?>" class="button button-primary">Exportar CSV</a>
                <a href="<?php echo esc_url($clear_url); ?>"
                   class="button button-secondary"
                   style="color:#b32d2e; border-color:#b32d2e;"
                   onclick="return confirm('Tem certeza que deseja APAGAR TODOS os resultados? Esta ação não pode ser desfeita.');">
                    Apagar todos os resultados
                </a>
            </p>

            <table class="wp-list-table widefat fixed striped">
                <thead><tr>
                    <th>ID</th><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Idade</th>
                    <th>Gênero</th><th>Pontuação</th><th>Nível</th><th>Consentimento</th><th>Data</th>
                </tr></thead>
                <tbody>
                <?php if (empty($results)): ?>
                    <tr><td colspan="10">Nenhuma resposta registrada ainda.</td></tr>
                <?php else: foreach ($results as $row): ?>
                    <tr>
                        <?php // 👇 CORRIGIDO AQUI (Missão 2: Trocado <?= por <?php echo) ?>
                        <td><?php echo (int) $row->id; ?></td>
                        <td><?php echo esc_html($row->nome); ?></td>
                        <td><?php echo esc_html($row->email); ?></td>
                        <td><?php echo esc_html($row->telefone); ?></td>
                        <td><?php echo (int) $row->idade; ?></td>
                        <td><?php echo esc_html($row->genero); ?></td>
                        <td><?php echo (int) $row->pontuacao; ?></td>
                        <td><?php echo esc_html($row->nivel); ?></td>
                        <td><?php echo $row->consentimento ? 'Sim' : 'Não'; ?></td>
                        <td><?php echo esc_html($row->data_hora); ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ------------------------------------------------------------
     *  EXPORTAR CSV
     * ------------------------------------------------------------ */

    public function handle_export() {
        if (!current_user_can('manage_options')) {
            wp_die('Sem permissão.', 'Acesso negado', ['response' => 403]);
        }
        
        // 👇 CORRIGIDO AQUI (Missão 3: Sanitização e unslash do Nonce)
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'trauma_quiz_export' ) ) {
            wp_die('Link expirado. Volte ao painel e clique de novo.', 'Link expirado', ['response' => 403]);
        }
        $this->export_csv();
    }

    private function export_csv() {
        global $wpdb;

        // Limpa qualquer saída anterior
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        // 👇 CORRIGIDO AQUI (Missão 4: esc_sql no nome da tabela)
        $table_name = esc_sql($this->table_name);
        $results = $wpdb->get_results( 
    $wpdb->prepare( "SELECT * FROM %i ORDER BY data_hora DESC", $table_name ) 
); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        // 👇 CORRIGIDO AQUI (Missão 5: date() trocado por gmdate())
        header('Content-Disposition: attachment; filename="trauma_quiz_respostas_' . gmdate('Y-m-d_His') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');

        // BOM UTF-8 para Excel abrir acentos corretamente
        // 👇 CORRIGIDO AQUI (Missão 5: Adicionado phpcs:ignore para o PCP não reclamar)
        fwrite($output, "\xEF\xBB\xBF"); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite

        fputcsv($output, ['ID','Nome','Email','Telefone','Idade','Gênero','Pontuação','Nível','Consentimento','Data']);
        if (!empty($results)) {
            foreach ($results as $row) {
                fputcsv($output, [
                    $row->id, $row->nome, $row->email, $row->telefone,
                    $row->idade, $row->genero, $row->pontuacao, $row->nivel,
                    $row->consentimento ? 'Sim' : 'Não', $row->data_hora
                ]);
            }
        }
        // 👇 CORRIGIDO AQUI (Missão 5: Adicionado phpcs:ignore)
        fclose($output); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        exit;
    }

    /* ------------------------------------------------------------
     *  APAGAR TUDO
     * ------------------------------------------------------------ */

    public function handle_clear() {
        if (!current_user_can('manage_options')) {
            wp_die('Sem permissão.', 'Acesso negado', ['response' => 403]);
        }
        
        // 👇 CORRIGIDO AQUI (Missão 3: Sanitização e unslash do Nonce)
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'trauma_quiz_clear' ) ) {
            wp_die('Link expirado. Volte ao painel e clique de novo.', 'Link expirado', ['response' => 403]);
        }

        global $wpdb;
        // 👇 CORRIGIDO AQUI (Missão 4: esc_sql no nome da tabela)
        $wpdb->query( 
    $wpdb->prepare( "TRUNCATE TABLE %i", $table_name ) 
); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        wp_safe_redirect(admin_url('admin.php?page=trauma-quiz&cleared=1'));
        exit;
    }

    /* ============================================================
     *  LGPD — EXPORTAR / APAGAR DADOS PESSOAIS
     * ============================================================ */

    public function register_exporter($exporters) {
        $exporters['trauma-quiz'] = [
            'exporter_friendly_name' => 'Dados do Trauma Quiz',
            'callback' => [$this, 'personal_data_exporter'],
        ];
        return $exporters;
    }

    public function personal_data_exporter($email, $page = 1) {
        global $wpdb;
        $data = [];
        // 👇 CORRIGIDO AQUI (Missão 4: esc_sql no nome da tabela)
        $table_name = esc_sql($this->table_name);
        $result = $wpdb->get_row( 
    $wpdb->prepare( "SELECT * FROM %i WHERE email = %s", $table_name, $email ) 
); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        
        foreach ($rows as $row) {
            $data[] = [
                'group_id'    => 'trauma-quiz',
                'group_label' => 'Respostas do Quiz',
                'item_id'     => "quiz-{$row->id}",
                'data'        => [
                    ['name'=>'Nome','value'=>$row->nome],
                    ['name'=>'Email','value'=>$row->email],
                    ['name'=>'Telefone','value'=>$row->telefone],
                    ['name'=>'Idade','value'=>$row->idade],
                    ['name'=>'Gênero','value'=>$row->genero],
                    ['name'=>'Pontuação','value'=>$row->pontuacao],
                    ['name'=>'Nível','value'=>$row->nivel],
                    ['name'=>'Data','value'=>$row->data_hora],
                ],
            ];
        }
        return ['data' => $data, 'done' => true];
    }

    public function register_eraser($erasers) {
        $erasers['trauma-quiz'] = [
            'eraser_friendly_name' => 'Dados do Trauma Quiz',
            'callback' => [$this, 'personal_data_eraser'],
        ];
        return $erasers;
    }

    public function personal_data_eraser($email, $page = 1) {
        global $wpdb;
        $deleted = $wpdb->delete($this->table_name, ['email' => $email], ['%s']);
        return ['items_removed' => $deleted > 0, 'items_retained' => false, 'messages' => [], 'done' => true];
    }
}

TraumaQuiz::get_instance();